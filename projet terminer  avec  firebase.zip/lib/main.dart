// lib/main.dart
import 'package:flutter/material.dart';
import 'package:firebase_core/firebase_core.dart'; // Import Firebase
import 'page_accueil.dart'; // Import de la page d'accueil

// Fonction main asynchrone car Firebase doit être initialisé
void main() async {
  WidgetsFlutterBinding.ensureInitialized(); // Assure que Flutter est prêt
  await Firebase.initializeApp(); // Initialise Firebase
  runApp(const MonAppli()); // Lance l'application
}

/// Classe principale de l'application.
class MonAppli extends StatelessWidget {
  const MonAppli({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Magazine Infos',
      theme: ThemeData(primarySwatch: Colors.blue, useMaterial3: true),
      home: const PageAccueil(), // Page d'accueil de l'application
    );
  }
}
