import 'dart:io';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:path/path.dart' as path;

class StorageService {
  final FirebaseStorage _storage = FirebaseStorage.instance;

  Future<Map<String, String>> uploadImage(File imageFile, String userId) async {
    final fileName =
        'profil_images/$userId/${DateTime.now().millisecondsSinceEpoch}_${path.basename(imageFile.path)}';
    final reference = _storage.ref().child(fileName);

    final snapshot = await reference.putFile(imageFile);
    final downloadUrl = await snapshot.ref.getDownloadURL();

    return {'url': downloadUrl, 'path': fileName};
  }

  Future<void> deleteImage(String? imagePath) async {
    if (imagePath != null && imagePath.isNotEmpty) {
      await _storage.ref().child(imagePath).delete();
    }
  }
}
